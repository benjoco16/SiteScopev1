// backend/alerts.js
import nodemailer from "nodemailer";
import { fcm } from "./firebaseAdmin.js";
import { q } from "./db.js";

// ---- SMTP transport (your cPanel settings) ----
export const transporter = nodemailer.createTransport({
  host: "cp-wc35.syd02.ds.network",
  port: 465,
  secure: true,
  auth: { user: process.env.EMAIL_USER, pass: process.env.EMAIL_PASS },
  tls: { rejectUnauthorized: false },
});

// Optional sanity check at boot
transporter.verify()
  .then(() => console.log("SMTP OK"))
  .catch((err) => console.error("SMTP FAIL", err));

const lastStatus = new Map();       // url -> "UP"/"DOWN"/"UNKNOWN"
const lastNotifiedAt = new Map();   // url -> timestamp
const NOTIFY_COOLDOWN_MS = parseInt(process.env.NOTIFY_COOLDOWN_MS || "600000", 10);

// ---- email sender (multi-recipient from DB) ----
async function sendEmailAlert(userId, url, status) {
  const { rows } = await q("SELECT email, alert_emails FROM users WHERE id=$1", [userId]);
  if (!rows[0]) return;

  const { email, alert_emails } = rows[0];
  let recipients = [email, ...(alert_emails || [])].slice(0, 3); // max 3

  for (let to of recipients) {
    const mailOptions = {
      from: `"SiteScope Alerts" <${process.env.EMAIL_USER}>`,
      to,
      subject: `SiteScope Alert: ${url} is ${status}`,
      text: `Website: ${url}\nStatus: ${status}\nTime: ${new Date().toLocaleString()}`,
    };

    const info = await transporter.sendMail(mailOptions);
    console.log(`📧 Email sent: ${info.messageId} → ${to} (${url} ${status})`);
  }
}



// ---- main exported hook (called by server.js) ----
export async function handleStatusChange(userId, url, currentStatus, opts = {}) {
  const { force = false } = opts;
  const key = `${userId}:${url}`;

  const prev = lastStatus.get(key);
  const now = Date.now();
  const last = lastNotifiedAt.get(key) || 0;
  const cooldownPassed = now - last > NOTIFY_COOLDOWN_MS;

  const isFirst = prev === undefined || prev === "UNKNOWN";
  const changed = prev !== currentStatus;

  // inside handleStatusChange
  if (force || isFirst || changed) {
    if (!force && !cooldownPassed) {
      console.log(`⏳ Cooldown active → skip alert for ${url}`);
    } else {
      // Email alert
      await sendEmailAlert(userId, url, currentStatus);

      // Push notifications
      const { rows: tokenRows } = await q("SELECT token FROM user_tokens WHERE user_id=$1", [userId]);
      for (const row of tokenRows) {
        try {
          await fcm.send({
            token: row.token,
            notification: {
              title: `SiteScope: ${url} is ${currentStatus}`,
              body: `Website ${url} is currently ${currentStatus}`,
            },
          });
          console.log("🔔 Push sent to", row.token);
        } catch (err) {
          console.error("Push error:", err);
        }
      }

      lastNotifiedAt.set(key, now);
    }
    lastStatus.set(key, currentStatus);
  }
}


export async function sendPushFCM(token, title, body) {
  try {
    await fcm.send({
      token,
      notification: { title, body },
    });
    console.log("Push sent:", title);
  } catch (err) {
    console.error("Push error:", err);
  }
}