import { useEffect, useRef, useState } from "react";
import { getStatus } from "../services/api";
import { ensureNotificationPermission, notifyUser } from "../utils/notify";

export default function MonitorList({ refreshKey }) {
  const [sites, setSites] = useState({});
  const last = useRef({}); // url -> { status }

  useEffect(() => {
    ensureNotificationPermission();

    const fetchData = async () => {
      const data = await getStatus(); // expects object: { url: {status,last_checked}, ... }
      setSites(data);

      // notify on changes
      Object.entries(data).forEach(([url, info]) => {
        const prev = last.current[url]?.status;
        if (prev && prev !== info.status) {
          if (info.status === "DOWN") {
            notifyUser("⚠️ Site DOWN", `${url} is DOWN as of ${new Date(info.last_checked).toLocaleString()}`);
          } else if (info.status === "UP") {
            notifyUser("✅ Site UP", `${url} is back UP as of ${new Date(info.last_checked).toLocaleString()}`);
          }
        }
      });

      last.current = Object.fromEntries(
        Object.entries(data).map(([url, info]) => [url, { status: info.status }])
      );
    };

    fetchData();
    const id = setInterval(fetchData, 5000);
    return () => clearInterval(id);
  }, [refreshKey]);

  const fmt = t => (t ? new Date(t).toLocaleString() : "N/A");

  return (
    <div>
      <h2 className="font-bold text-lg mb-2">Monitored Sites</h2>
      <ul>
        {Object.entries(sites).map(([url, info]) => (
          <li key={url} className="mb-2">
            <strong>{url}</strong> →{" "}
            <span className={info.status === "UP" ? "text-green-600 font-semibold" : "text-red-600 font-semibold"}>
              {info.status === "UP" ? "✅ UP" : "❌ DOWN"}
            </span>
            <br />
            <small className="text-gray-500">Last checked: {fmt(info.last_checked)}</small>
          </li>
        ))}
      </ul>
    </div>
  );
}
