// frontend/src/firebase.js
import { initializeApp } from "firebase/app";
import { getMessaging, getToken, onMessage, isSupported } from "firebase/messaging";

/** 🔧 paste your Firebase config here */
const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT_ID.appspot.com",
  messagingSenderId: "YOUR_SENDER_ID",
  appId: "YOUR_APP_ID",
};

const app = initializeApp(firebaseConfig);

async function getSW() {
  if (!("serviceWorker" in navigator)) return null;
  // ensure the SW is registered at the root path so it can receive pushes
  return await navigator.serviceWorker.register("/firebase-messaging-sw.js");
}

export async function requestPermissionAndToken() {
  try {
    const supported = await isSupported();
    if (!supported) return null;

    const swReg = await getSW();
    const messaging = getMessaging(app);

    const token = await getToken(messaging, {
      vapidKey: "YOUR_WEB_PUSH_CERTIFICATE_KEY_PAIR",
      serviceWorkerRegistration: swReg || undefined,
    });
    return token || null;
  } catch (err) {
    console.error("FCM permission/token error:", err);
    return null;
  }
}

/** optional: foreground messages while app is open */
export function onForegroundMessage(cb) {
  isSupported().then((ok) => {
    if (!ok) return;
    const messaging = getMessaging(app);
    onMessage(messaging, (payload) => cb?.(payload));
  });
}
